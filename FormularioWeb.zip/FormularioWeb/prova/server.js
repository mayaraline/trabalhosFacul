// Função que mostra o valor do input num alert
function mostrarValor() {
    alert(document.getElementById("nome").value + document.getElementById("email").value + document.getElementById("curso").value);
}


// Evento que é executado ao clicar no botão de enviar
document.getElementById("submit").onclick = function(e) {
    mostrarValor();
    e.preventDefault();
}

var form = document.getElementById('formulario');
var campo = document.getElementById('nome');

form.addEventListener('submit', function(e) {
    // alerta o valor do campo
    alert(nome.value + email.value);

    // impede o envio do form
    e.preventDefault();
});